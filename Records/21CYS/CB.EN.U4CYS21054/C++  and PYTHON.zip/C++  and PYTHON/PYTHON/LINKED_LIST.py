class node:
    def __init__(self,data):
        self.data = data 
        self.next = None

class linkedlist:
    def __init__(self):
        self.head = None
    
    def printll(self):
        temp = self.head
        while(temp):
            print(temp.data)
            temp = temp.next   

    def addEnd(self,i):
        temp = self.head
        while(temp.next):
            temp = temp.next
        op = node(i)
        temp.next = op
    
    def addBegin(self,i):
        temp = self.head
        op = node(i)
        op.next = temp
        self.head = op
    
    def rbegin(self):
        temp = self.head
        temp2 = temp.next
        self.head = temp2
        temp.data = None
        temp.next = None
    
    def rend(self):
        temp = self.head
        while(temp.next.next):
            temp = temp.next
        temp.next = None
    
    def insert(self,loc,i):
        if loc == 0:
            ll.addBegin(i)
        else:
            temp = self.head
            d = 0
            while(temp.next):
                if d == loc:
                    break
                d = d + 1
                temp = temp.next

            l = node(i)  
            temp2 = temp.next  
            temp.next = l
            l.next = temp2

    def size1(self):
        temp = self.head
        i = 0
        while(temp):
            i = i + 1
            temp = temp.next
        print("size is",i)
        return i
    
    def remove(self,i):
        if i==0:
            ll.rbegin()
        else:
            temp = self.head
            op = 0
            while(temp):
               if op == i-1:
                   break
               op = op + 1
               temp = temp.next
            temp.next = temp.next.next
            

ll = linkedlist() 
ll.head = node(13)
second = node(31)
third = node(57)

ll.head.next = second
second.next = third

ll.addEnd(25)
ll.addBegin(12)
ll.rbegin()
ll.rend()
ll.insert(0,96)
ll.remove(ll.size1()-1)
ll.size1()
ll.printll()

















# # Python program for traversal of a linked list
# # Node class


# class Node:

# 	# Function to initialise the node object
# 	def _init_(self, data):
# 		self.data = data # Assign data
# 		self.next = None # Initialize next as null


# # Linked List class contains a Node object
# class LinkedList:

# 	# Function to initialize head
# 	def _init_(self):
# 		self.head = None

# 	# This function prints contents of linked list
# 	# starting from head
# 	def printList(self):
# 		temp = self.head
# 		while (temp):
# 			print(temp.data)
# 			temp = temp.next


# # Code execution starts here
# if _name_ == '_main_':

# 	# Start with the empty list
# 	llist = LinkedList()

# 	llist.head = Node(1)
# 	second = Node(2)
# 	third = Node(3)

# 	llist.head.next = second # Link first node with second
# 	second.next = third # Link second node with the third node

# 	llist.printList()
