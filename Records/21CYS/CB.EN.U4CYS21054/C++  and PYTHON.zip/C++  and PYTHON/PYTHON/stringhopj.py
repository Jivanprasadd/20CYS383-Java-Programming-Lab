def stringMan(s):
    #@start-editable@


    l=len(s)
    s=s.split(" ")
    string_upper=[]
    string_capitalize=[]
    if l%2==0:
        for y in s:
            string_upper.append(y.upper())
            s="-".join(string_upper)
    else:
        for x in s:
            string_capitalize.append(x.capitalize())
            s = "-".join(string_capitalize)


   #@end-editable@ 
    return s

s=input()
myString = stringMan(s)
print (myString)
