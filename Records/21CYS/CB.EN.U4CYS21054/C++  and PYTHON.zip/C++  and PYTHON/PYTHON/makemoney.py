# cook your dish here
a = int(input())
lst = []
for x in range(a):
    b, c, d = map(int, input().split())
    for y in range(b):
        e = int(input())
        lst.append(e)
    i = 0
    m=
    c=0
    while (m<= c):
        lst[i] = c
        m = m + d
        c=c+d
        i = i + 1
        print(lst)
    sum = 0
    for z in lst:
        sum = sum + z
    print(sum)

