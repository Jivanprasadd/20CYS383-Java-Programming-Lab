def product(a, b):
    p = a * b
    print(p)
def product(a, b, c):
    p = a * b*c
    print(p)
product(4, 5)
product(4, 5, 5)