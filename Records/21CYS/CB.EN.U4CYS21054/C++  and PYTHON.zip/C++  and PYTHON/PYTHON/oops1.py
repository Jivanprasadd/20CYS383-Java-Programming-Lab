class individual:
    def __init__(self,character_name):
        self.character_name=character_name
    def get_character_name(self):
        return self.character_name
individual1=individual("Buster")
individual2=individual("Tobias")
a=individual1.get_character_name()
b=individual2.get_character_name()
print(a)
print(b)