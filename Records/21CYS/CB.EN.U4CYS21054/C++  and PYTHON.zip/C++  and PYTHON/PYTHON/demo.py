import random
import csv

n = int(input("Enter the total number of subjects: "))
l = []
m = []
fac = []
for i in range(n):
    l.append(input("Subject Name: "))
    m.append(int(input("Subject Credit: ")))
    fac.append(input("Faculty Name: "))
    print("\n")

q = []
for i in range(n):
    for p in range(m[i]):
        q.append(l[i])

if len(q) % 5 != 0:
    for i in range(5 - (len(q) % 5)):
        q.append("Free")
r = len(q) // 5
mainlist = []
for i in range(5):
    templist = []
    for p in range(r):
        s = random.choice(q)
        templist.append(s)
        q.remove(s)
    templist.insert((r // 2), "")
    mainlist.append(templist)
print("Monday   Tuesday   Wednesday   Thursday   Friday")
for i in range(r + 1):
    s = "{:<9} {:^9} {:^9} {:^9} {:^9}".format(mainlist[0][i], mainlist[1][i], mainlist[2][i], mainlist[3][i],
                                               mainlist[4][i])
    print(s)

f = open("new.csv", "w", newline="")
cwriter = csv.writer(f)
l1 = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
l2 = [""]
for i in range(r):
    if i == r // 2:
        l2.append("Lunch")
        l2.append("Period " + str(i + 1))
    else:
        l2.append("Period " + str(i + 1))
cwriter.writerow(l2)
for i in range(5):
    cwriter.writerow([l1[i]] + mainlist[i])

cwriter.writerow(["", ""])
cwriter.writerow(["", ""])
cwriter.writerow(["Subject Name", "Credit", "Faculty"])

for i in range(n):
    cwriter.writerow([l[i], m[i], fac[i]])

f.close()