class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def show(self):
        print(self.x,end=" ")
        print(self.y)
    def move(self,i,j):
        self.x=self.x+i
        self.y=self.y+j
p1=Point(2,3)
p1.show()
p1.move(10,-10)
p1.show()