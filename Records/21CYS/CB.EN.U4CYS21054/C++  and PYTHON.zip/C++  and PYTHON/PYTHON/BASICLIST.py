a=[1, 2, 3]
b=[4, 5, 6]
d=[]
c=a+b
print(c)
for x in range(3):
    for y in c:
        d.append(y)
print(d)
print(a[1:3])
print(b[:3])
print(c[3:])
print(c[1:3])
print(c)