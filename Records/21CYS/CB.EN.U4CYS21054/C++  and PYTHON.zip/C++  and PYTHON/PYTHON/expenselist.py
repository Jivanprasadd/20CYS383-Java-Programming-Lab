a=int(input())
for x in range(a):
    p=0
    b,c=map(int,input().split())
    p=pow(2,c)
    for x in range(b):
        p=p-p/2
    print(int(p))