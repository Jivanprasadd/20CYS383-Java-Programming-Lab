class Geek:
    # protected data members
    _name = "R2J"
    _roll = 1706256

    # public member function
    def displayNameAndRoll(self):
        # accessing protected data members
        print("Name: ", self._name)
        print("Roll: ", self._roll)
obj = Geek()
obj.displayNameAndRoll()
print(obj._name)