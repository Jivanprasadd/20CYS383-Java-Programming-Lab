# cook your dish here
a = int(input())
for i in range(a):
    g = int(input())
    arr = list(map(int, input().split()))
    b = []
    c = []
    f = 0
    for j in range(len(arr)):
        if arr[j] not in b:
            e= arr.count(arr[j])
            c.append(e)
            b.append(arr[j])
    for z in c:
        if(z>2):
            f=1
            break
    if(f==1):
        print("No")
    else:
        print("Yes")
