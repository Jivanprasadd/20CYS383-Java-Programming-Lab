# cook your dish here
a = int(input())
alphabet=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
for i in range(a):
    b=int(input())
    s=input()
    l=list(s)
    for j in range(len(l)):
        temp=l[j]
        l[j]=l[j+1]
        l[j+1]=temp
    print(l)
