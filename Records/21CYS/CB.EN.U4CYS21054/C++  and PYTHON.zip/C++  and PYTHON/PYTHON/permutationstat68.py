a=int(input())
for x in range(a):
    b=int(input())
    c=list(map(int,input().split()))
    c.sort()
    s=0
    for l in range(b):
        for y in range(b):
            if c[y]>b:
                print("-1")
                break
        s=s+((l+1)-c[l])
    print(s)




