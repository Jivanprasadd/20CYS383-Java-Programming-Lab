class students:
    def __init__(self,name,id):
        self.__name=name
        self.__id=id
    def printdetails(self):
        print(self.__name)
        print(self.__id)
p1=students("JIvan",100)
p1.printdetails()
