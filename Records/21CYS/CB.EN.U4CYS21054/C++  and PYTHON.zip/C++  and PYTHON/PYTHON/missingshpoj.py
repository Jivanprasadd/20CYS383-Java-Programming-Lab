def findMissing(N,stringOfRolls):
    missingStatus = "All Present"
    stringOfRolls=stringOfRolls.sort()
    for i in range(1,N+1):
        for x in stringOfRolls:
            if i!=x:
                
        
        
    
    return missingStatus


N=int(input())
stringOfRolls=input()
missingRoll=findMissing(N,stringOfRolls)
print(missingRoll)
