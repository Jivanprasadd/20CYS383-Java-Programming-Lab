a=int(input("Enter a number:"))
if a%2==0 and a%3==0:
    print("Divisible by 6")
else:
    print("Not divisible by 6")
