a=input("Enter the string")
c=a[::-1]
if(a==c):
    print("It is a palindrome")
else:
    print("not a palindrome")