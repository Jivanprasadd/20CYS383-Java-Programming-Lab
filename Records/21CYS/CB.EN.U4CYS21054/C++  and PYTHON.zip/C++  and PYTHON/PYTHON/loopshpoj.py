n=int(input())
if(n>0 and n<21):
    for i in range(0,n):
        print(i*i)
