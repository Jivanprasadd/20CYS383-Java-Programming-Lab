#include<iostream>
using namespace std;

class cuboid
{
	protected:
		int length;
		int breath;
		int height;
	public:
		int read(int a,int b,int c)
		{
			length=a;
			breath=b;
			height=c;
		}
		int calculatearea()
		{
			return length*breath*height;
		}
};
class reactangle : public cuboid
{
public:
	int rect()
	{
        cout<<"the area of the rectangle is:" <<length*breath;
        
	}
};
int main()
{
	int p,q;
	cuboid c1;
	reactangle t;
	c1.read(5,6,8);
	p=c1.calculatearea();
	t.rect();
	cout<<"the area of the cuboid:"<<p;
}
