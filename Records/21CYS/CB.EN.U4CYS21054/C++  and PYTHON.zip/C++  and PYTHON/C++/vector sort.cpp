#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int n,temp;
    cin>>n;
    vector <int> v;
    int arr[n];
    for(int j=0;j<n;j++)
    {
        cin>>arr[j];
    }
    for(int j=0;j<n;j++)
    {
        cout<<arr[j];
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        v.push_back(arr[i]);
    }
    for(int j=0;j<n;j++)
    {
        cout<<v[j];
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=i;j<n;j++)
        {
            if(v[i]>v[j+1])
            {
                temp=v[i];
                v[i]=v[j+1];
                v[j+1]=temp;
            }
        }
    }
    /*for(int j=0;j<n;j++)
    {
       cout<<v[j]<<endl;
    }
    */
    return 0;
}
