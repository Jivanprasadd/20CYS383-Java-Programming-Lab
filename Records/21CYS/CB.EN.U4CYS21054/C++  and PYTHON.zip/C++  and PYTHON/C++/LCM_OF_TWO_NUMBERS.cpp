/* To find LCM of two numbers */
#include <iostream>
using namespace std;

int main()
{
    int n1, n2, max;
    cout << "Enter the first number : ";
    cin >> n2;
    cout << "Enter tthe second number : ";
    cin >> n2;
    
    max = (n1 > n2) ? n1 : n2;

    do
    {
        if (max % n1 == 0 && max % n2 == 0)
        {
            cout << "LCM = " << max;
            break;
        }
        else
            ++max;
    } while (true);
    
    return 0;
}
