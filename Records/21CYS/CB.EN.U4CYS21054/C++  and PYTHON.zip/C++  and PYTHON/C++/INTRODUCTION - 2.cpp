#include<iostream>
int main()
{
	int a;
	std :: cin >> a;
	std :: cout << a;
	return 0;
}

/* :: - scope resolution operator */
