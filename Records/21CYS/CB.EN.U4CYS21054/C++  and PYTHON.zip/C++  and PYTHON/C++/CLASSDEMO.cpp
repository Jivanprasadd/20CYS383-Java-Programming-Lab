#include<iostream>
using namespace std;

class array_Details
{
public:
	int a[10];
	void readarray()
	{
		int i;
		cout<<"Enter the value of the element: "<<endl;
		for(i=0;i<10;i++)
		{
			cin>>a[i];
		}
	}
};
class functions : public array_Details
{
public:
	int sort(int b[10],int size)
	{
	int i,j,temp;
    for (i = 0; i < size; ++i)
    {
        for (j = i + 1; j < size; ++j)
        {
            if (b[i] > b[j])
            {
                temp =  b[i];
                b[i] = b[j];
                b[j] = temp;
            }
        }
    }
    cout<<"Sorted array: \n";
    for (i = 0; i < size; ++i)
        cout<<b[i]<<endl;
    return 0;
	}
};
class binarysearch: public functions
{
public:
	int binarySearch(int arr[], int p, int r) {
	int num;
	cin>>num;
   if (p <= r) {
      int mid = (p + r)/2;
      if (arr[mid] == num)
         return mid ;
      if (arr[mid] > num)
         return binarySearch(arr, p, mid-1);
      if (arr[mid] < num)
         return binarySearch(arr, mid+1,r);
   }a
   return -1;
}
};
int main()
{
	int l,e;
	array_Details m;
	functions n;
	binarysearch y;
	m.readarray();
	n.sort(m.a,10);
	e=y.binarySearch(n.a,0,9);
	cout<<"the element is found at:"<<e;
	return 0;
}
