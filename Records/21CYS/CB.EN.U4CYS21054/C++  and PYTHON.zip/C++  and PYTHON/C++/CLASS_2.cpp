#include <iostream>
using namespace std;

class student
{
	private:
	int mark;
	public:
	void fun()
	{
		mark=10;
		cout << mark ;
	}
};

int main()
{
    student S,T;
    S.fun();
    cout << "\n" ;
    T.fun();
    return 0;
    
}
