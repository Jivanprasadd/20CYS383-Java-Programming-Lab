
#include<iostream>
using namespace std;
class A 
{
public:
  int pa;
private:
  int aa;
protected:
  int ab;
public:
A()
{
    pa=10;
    aa=50;
    ab=30;
}
void dispa()
    {
        cout<<"Value of pa from class A is :"<<pa<<"\n";
        cout<<"Value of aa from class A is :"<<aa<<"\n";
        cout<<"Value of ab from class A is :"<<ab<<"\n";
    }

};
class B  
{
public:
  int pb;
private:
  int ba;
protected:
  int bb;
public:
B()
{
    pb=34;
    ba=35;
    bb=61;
}
    void dispb()
    {
        cout<<"Value of pa from class B is:"<<pb<<"\n";
        cout<<"Value of ba from class B is :"<<ba<<"\n";
        cout<<"Value of bb from class B is :"<<bb<<"\n";
    }
  
};
class C 
{
public:
  int pc;
private:
  int ca;
protected:
  int cb;
public:
C()
{
    pc=24;
    ca=28;
    cb=35;
}
    void dispc()
    {
        cout<<"Value of pc from class C is:"<<pc<<"\n";
        cout<<"Value of ca from class c is :"<<ca<<"\n";
        cout<<"Value of cb from class C is :"<<cb<<"\n";
    }
  
};
class D:public A, private B, protected C
{
public:
D()
{
    cout<<"FROM CLASS D";
    
}
};

int main()
{
    A a;
    a.dispa();
    B b;
    b.dispb();
    C c;
    c.dispc();
    D d;
    
}

