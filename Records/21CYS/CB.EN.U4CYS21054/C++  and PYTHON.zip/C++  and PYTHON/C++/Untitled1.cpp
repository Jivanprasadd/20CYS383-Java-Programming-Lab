#include<iostream>
using namespace std;
int main()
{
	int a,b,hcf,lcm;
	cin>>a>>b;
	for(int i=1; i<=a || i<=b;i++)
	{
		if(a%i==0)
		{
			hcf=i;
		}
	}
	lcm=a*b/hcf;
	cout<<"HCF IS "<<hcf<<endl;
	cout<<"LCM IS "<<lcm;
}
