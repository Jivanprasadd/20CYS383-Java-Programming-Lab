#include<iostream>
using namespace std;

class cuboid
{
	private:
		int length;
		int breath;
		int height;
	public:
		 cuboid(int a,int b,int c)
		{
			length=a;
			breath=b;
			height=c;
		}
		int calculatearea()
		{
			return length*breath*height;
		}
};
int main()
{
	int p;
	cuboid c1(5,10,15);
	p=c1.calculatearea();
	cout<<p;
}
