#include<iostream>
using namespace std;

template<class t>
class car
{
    private:
         t carid;
         t price;
    public:
         void setvalue(t b,t c)
         {
             carid=b;
             price=c;
         }
         
         void getvalue()
         {
             cout<<carid;
             cout<<price;
         }
};

int main()
{
    car <int> obj;
    obj.setvalue(1,10000);
    obj.getvalue();
}