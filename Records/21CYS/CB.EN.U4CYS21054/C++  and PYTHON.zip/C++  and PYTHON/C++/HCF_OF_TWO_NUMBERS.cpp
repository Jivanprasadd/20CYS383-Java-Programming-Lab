/* To find HCF (GCD) of two numbers */
#include <iostream>
using namespace std;

int main() {
  int n1, n2, hcf;
  cout << "Enter the first number : ";
  cin >> n1;
  cout << "Enter the second number : ";
  cin >> n2;
   
    int temp = n2;
    n2 = n1;
    n1 = temp;
  }
    
  for (int i = 1; i <=  n2; ++i) {
    if (n1 % i == 0 && n2 % i ==0) {
      hcf = i;
    }
  }

  cout << "HCF = " << hcf;

  return 0;
}
