#include <iostream>
using namespace std;
int main()
{
	int a;
	cin >> a;
	count << a;
	return 0;
}
