#include <iostream>
using namespace std;

int main() 
{
    int t,c,m,r,f=1;
    cin>>t;
    for (int i = 0; i < t; i++) 
    {
        cin>>c>>m>>r;
        for (int i = 0; i <= c; i++)
        {
            if(r==i*m)
            {
                cout<<"YES"<<"\n";
                f=0;
                break;
            }
        }
        if(f)
        {
        cout<<"NO"<<"\n";
        }
    }
	return 0;
}

