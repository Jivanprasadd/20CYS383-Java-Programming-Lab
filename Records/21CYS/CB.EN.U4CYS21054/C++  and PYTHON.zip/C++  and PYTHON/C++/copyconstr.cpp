#include<iostream>
using namespace std;

class cuboid
{
	private:
		int length;
		int breath;
		int height;
	public:
		 cuboid(int a,int b,int c)
		{
			length=a;
			breath=b;
			height=c;
		}
		cuboid(const cuboid &d)
		{
			length=d.length;
			breath=d.breath;
			height=d.height;
		}
		int calculatearea()
		{
			return length*breath*height;
		}
};
int main()
{
	int p,p1;
	cuboid c1(5,10,15);
	p=c1.calculatearea();
	cuboid c2(c1);
	p1=c2.calculatearea();
	cout<<p<<p1;
}
