#include<iostream>
using namespace std;
class Triangle
{
	private:
	int l;
	int b;
	
	public:
    cin >> l;
	cin >> b;
	
	void area()
	{
		cout << 0.5*l*b << endl;
	}
};

int main()
{
	Triangle T;
	T.area();
}
