#include<iostream>
using namespace std;
void swap(int &num1 , int &num2)
{
	int temp;
    temp=num1;
    num1=num2;
    num2=temp;
}
int main()
{
	int a,b;
	cout << "Enter first integer : ";
    cin >> a;
    cout << "Enter second integer : ";
    cin >> b;
	cout<<"\n Before swapping"<<"\n A = "<<a<<"\n B = "<<b<<endl;
	swap(a,b);
    cout<<"\n After swapping"<<"\n A = "<<a<<"\n B = "<<b<<endl;
    return 0;
}

/*

Program written by Sir :

void swap(int *a , int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}
int main()
{
	int x = 6;
	int y = 7;
	swap(&x,&y); 
	cout << x << y;
}

--------------------------

void swap(int &a , int &b)
{
	int temp = a;
	a = b;
	b = temp;
}
int main()
{
	int x = 6;
	int y = 7;
	swap(x,y); 
	cout << x << y;
}


*/

