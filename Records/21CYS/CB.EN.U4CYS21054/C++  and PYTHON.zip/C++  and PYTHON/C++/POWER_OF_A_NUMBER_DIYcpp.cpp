#include<iostream>
using namespace std;
int main()
{
	int e,b,n;
	cin>>e>>b;
	n=1;
	for(int i=0;i<e;i++)
	{
		n=n*b;
	}
	cout<<"power of the given number is:"<<n;
}
