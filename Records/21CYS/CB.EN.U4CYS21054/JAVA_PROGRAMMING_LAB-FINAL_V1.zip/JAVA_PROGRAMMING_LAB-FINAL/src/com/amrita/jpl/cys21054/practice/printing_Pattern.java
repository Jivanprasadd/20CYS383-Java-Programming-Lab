package com.amrita.jpl.cys21054.practice;

/**
 * A program to print a specific pattern using nested loops.
 */
public class printing_Pattern {
    /**
     * Prints a specific pattern using nested loops.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Code of Java for loop
        for (int i = 1; i <= 5; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println("* * * * *  ===================================");
        }

        for (int i = 1; i <= 5; i++) {
            System.out.println("==============================================");
        }
    }
}
